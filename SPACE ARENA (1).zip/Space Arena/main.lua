-----------------------------------------------------------------------------------------
-- Yash Singh
-- main.lua
-- Space Arena Game - remake of asteroids.
-----------------------------------------------------------------------------------------

-- 1. Requires 
-- Composer
local composer = require "composer"
-- For OOP
require ("classes.30logglobal")
-- Physics Engine
local physics = require ( "physics" )
physics.start()
-- Don't need gravity
physics.setGravity( 0, 0 )

--Degub output for composer - Mainmenu scene.



composer.isDebug = true

composer.gotoScene( "scenes.mainMenu" )	-- goto the menu
