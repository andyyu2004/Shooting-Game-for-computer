--======================================================================--
--== Enemy Class factory
--======================================================================--
local Enemy = class() -- define Enemy as a class (notice the capitals)
Enemy.__name = "Enemy" -- give the class a name

--======================================================================--
--== Require dependant classes
--======================================================================--
local pt = require("Classes.printTable")



--======================================================================--
--== Initialization / Constructor
--======================================================================--
function Enemy:__init( group, xloc, yloc, health, speed)
	self.group = group  --------------sets variables that will be used in the rest of the methods
	self.xloc = xloc ----------------- Is required for the methods to work otherwise they will come up with nil
	self.yloc = yloc
	self.size = size
	self.health = health
	self.speed = speed or 60
	self.randomx = math.random(-50,50)
	self.randomy = math.random(-50,50)
	self.count=0
	self.normDeltaX=0
	self.normDeltaY=0
	self.contactHealth = 150
	self.x = x
	self.y = y

	self:drawEnemy()
end

--======================================================================--
--== Code / Methods
--======================================================================--
function  Enemy:drawEnemy() -- This method draws the enemy
	--print("draw normal enemy")
	self.enemy = display.newCircle(self.group, self.xloc, self.yloc, 5.5) -- displayng enemy at giving variables
	--self.enemy = display.newImage(self.group, "images/enemy.png", self.xloc, self.yloc, 5.5)

	self.enemy:setFillColor( 0, 1, 0, 1)
	physics.addBody( self.enemy, "dynamic" ) -- add a physics body so enemies dont overlap, instead they bounce against eachother
	self.enemy.id = "enemy"

	self:enemyCollision() -- call enemy collision to check if the enemy has collided with anything
	self:setPlayerCoordinates() -- call player coordinates to self so the enemy can know where to path towards

end	

function Enemy:enemyCollision()	  -- If the enemy collides with the player or the bullet then it will destroy itsself 
	self.enemy.collision = function (target, event) ------- call the deconstructor method - if the enemy collides with 
		if event.other.id == "player" or event.other.id == "bullet" then

			self:deconstructor() -------- the player then the players health will reduce by the amount set in INIT
			self.enemy:removeSelf() ----- on collision
			
			local options = {
				name = "contactHealth",
				health = self.contactHealth
				}
			if event.other.id == "player" then
				Runtime:dispatchEvent(options) 
			end
		
		
		
		end
	end
	self.enemy:addEventListener("collision")
end


function Enemy:setPlayerCoordinates() ---------- listens for the custom event sent out by playerclass
	self.setPlayerCoordinates = function (event) ------- this allows the enemy to path towards the players x and y
		if self.enemy.x then ------------- location by finding the coordinates based off the custom event
			self.playerX=event.x
			self.playerY=event.y
			--print(self.playerX..)
		end
			self:setEnemyDirection()  -- calling set enemy direction to make the enemy physically move
		--self:drawBullet() 
	end
	Runtime:addEventListener("playerLocation", self.setPlayerCoordinates)  --- without an event listener the enemy cannot listen for the custom event
return
end

function Enemy:setEnemyDirection() -- this function sets values for the enemies movement direction based on x and y velocities
	--print(self.playerX)
	if self.enemy.x then
		local deltaX = self.playerX - self.enemy.x  ---- complex code to add variation to enemy movement 
		local deltaY = self.playerY - self.enemy.y
		self.normDeltaX = deltaX / math.sqrt(math.pow(deltaX,2) + math.pow(deltaY,2))
		self.normDeltaY = deltaY / math.sqrt(math.pow(deltaX,2) + math.pow(deltaY,2))
		self:moveEnemy()  -- call move enemy to set x and y velocity based off deltax and delta y
	end
	--print("deltaX = "..deltaX)
end
	
function Enemy:moveEnemy() -- Moves the enemy towards player x and player y coords.
	if self.count == 30 then  ----------- is reguarly updated as enemy always listening for player coords
		local randomX = math.random(-0.8,0.8)  ------ random x is added so enemy doesnt bunch together
		local randomY = math.random(-0.8,0.8) ---- random y is added so enemy doesnt bunch together
		self.enemy:setLinearVelocity ((self.normDeltaX + randomX) * self.speed, (self.normDeltaY + randomY) * self.speed)
		self.count = 0
	end
	self.count = self.count + 1
end



function Enemy:deconstructor() -- calls deconstructor to nil out enemy and remove event listeners so no erroes occur
	
	
	self.enemy.finalize = function()
		Runtime:removeEventListener("playerLocation", self.setPlayerCoordinates)
		self.enemy:removeEventListener("collision")
		self.enemy = nil
		self = nil
		print("deconstuted enemy")
	end
	self.enemy:addEventListener("finalize")
end
--======================================================================--
--== Return factory
--======================================================================--
return Enemy