

-- =============================================================
-- Yash Singh
-- Player.lua
-- Player class,  creates the player
--======================================================================--
--== Player Class factory
--======================================================================--
 local Player = class()

 
 Player.__name = "Player"
 
 
 local pt = require("Classes.printTable")-- helper class to use when developint
-- pt.print_r(....) will print the contents of a table
local bulletClass = require ("Classes.Bullet") -- class for the bullet





--=============================Constructor=================================--

function Player:__init(group, xloc, yloc, playerBulletSpeed, playerBulletInterval, health)
	-- Constructor for class
		-- Parameters:
		--	group - the group where the game should be inserted into
		--	xloc, yloc - location where it will be drawn
		--  bulletSpeed - speed at which bullets will fire
		--  bulletInterval - gap between bullets
		-- parameters essential for rest of code to work (e.g needed in methods)
	self.group = group
	self.xloc = xloc
	self.yloc = yloc
	self.xVelocity=0
	self.yVelocity=0
	self.rRotation=0
	self.lRotation=0
	self.fullHealth = health
	self.currentHealth = self.fullHealth
	self.rotation=0
	self.canFire = 1
	self.bulletSpeed = bulletSpeed
	self.bulletInterval = bulletInterval
	self.speed = 100
	self:drawPlayer()
	self:drawHealth()

end

function Player:drawPlayer() -- Draws the player - calls methods that set movement and health
	
	self.player=display.newImage ( self.group, "images/player.png", self.xloc, self.yloc)
	self.player.id= "player"
	physics.addBody ( self.player, "dynamic" )
	self.player.isFixedRotation = true -- stops physics rotation
	self:rotationalVelocity()
	self:setRotate() 
	self:sendPlayerCoordinates()
	self:changeHealth()
	
end


function Player:drawHealth() -- This draws the players health as a health bar at top of screen
		if self.currentHealth <=0 then -- if health = 0 then game will end 
			self.currentHealth = 0
			self.player.collision = function(target, event)
				self:deconstructor()
				display.remove(self.player)
			end
	
		self.player:addEventListener("collision")
	
		self:deconstructor()
		display.remove(self.player)
		end
		self.healthBarPercentage = self.currentHealth/self.fullHealth
		if self.healthBar then
			display.remove (self.healthBar)
		end
	self.healthBar = display.newRect (self.group, display.contentCenterX, 2.5, 100*self.healthBarPercentage, 15)
	self.healthBar:setFillColor(1,0,0)
	self.healthDisplay = display.newText (self.group, "Health", display.contentCenterX, -15, native.systemFontBold, 14)
end

function Player:changeHealth() -- custom event that lets the players health decrease if player collides with enemy
	self.changeHealth = function(event)
		self.currentHealth = self.currentHealth - event.health
		self:drawHealth()
	end
	Runtime:addEventListener("contactHealth", self.changeHealth)
end
	

function Player:rotationalVelocity() -- custom event that listens for a key press.
 -- sets the rotational velocity of the player ( velocity based off x and y rotation of player image)
	self.setRotationalVelocity = function (event)
		self.rotationalVelocity = event.rotationalVelocity
		self.xVelocity = event.playerSpeed * math.sin(math.rad(self.player.rotation))
	    self.yVelocity = -event.playerSpeed * math.cos(math.rad(self.player.rotation))	
		
	    self:move()
	end
Runtime:addEventListener("rotationalVelocity", self.setRotationalVelocity)
end

function Player:setRotate() -- listens for key press and rotates the player
	
		self.setRRotation=function(event)
		self.rRotation=event.rRotation
 -- if statements are used to ensure that player.rotation stays within limit of 0-360 degress
 -- if this was not true then rest of code would not work as player.rotation cannot be above 360 or below 0 to set linear velocity
			if self.player.rotation >= 350 then
				self.player.rotation = 0
			else 
				self.player.rotation = self.player.rotation +10 
			end

		print(self.player.rotation)
		end
		Runtime:addEventListener("rRotation", self.setRRotation)
		
		self.setLRotation=function(event)
		self.lRotation=event.rRotation

			if self.player.rotation <= 0 then
				self.player.rotation = 350
			else
			self.player.rotation = self.player.rotation -10
			end

		print(self.player.rotation)
		end
		Runtime:addEventListener("lRotation", self.setLRotation)
		
	end
	
function Player:move() -- moves the player based of key press, rotation and velocity
	if self.player and self.player.removeSelf then
		self.player.rotation = self.player.rotation
	
		self.player:setLinearVelocity(self.xVelocity,self.yVelocity)
		print (" x ", self.player.x, " y ", self.player.y)
		self:checkPos() -- lets the player wrap around screen
	

		
	end
end

function Player:sendPlayerCoordinates() -- sends custom event for enemy pathing
	if self.player and self.player.removeSelf then --sends enemy class and whoever else might need it the coordinates of player so they can do the necessary calculations to move towards and fire towards player etc... as the self.player.x/y are not accessible from other classes.
		self.sendPlayerCoordinates = function()
			local customEvent = {
				name = "playerLocation",
				x = self.player.x,
				y = self.player.y
				}
				Runtime:dispatchEvent(customEvent)
				--print("dispatchEvent")
		end
	end
	Runtime:addEventListener("enterFrame", self.sendPlayerCoordinates)
end


function Player:checkPos() -- allows the player to wrap around the screen which is pretty cool.
	if self.player and self.player.removeSelf then
		if self.player.x >= 320 then
			self.player.x = 5
		elseif self.player.x <= 0 then
			self.player.x = 315
		elseif  self.player.y >= 520 then
			self.player.y = -35
		elseif self.player.y <= -40 then
			self.player.y = 515
			
		else 
		self.player.x = self.player.x
		self.player.y = self.player.y					
		end
	end
end






function Player:fireBullet() -- creates a bullet and fires it, giving a bullet delay of z ms
	if not self.player or self.player.removeSelf == nil then return end
	if self.canFire == 1 then
		self.canFire = 0
		bulletClass:new(self.group, self.bulletSpeed, self.player.x, self.player.y, self.player.rotation)
		self.timer = timer.performWithDelay(250, 
		function()
			self.canFire = 1
		end)
	end
end


function Player:deconstructor()
	-- a finalize event is called when a display object is removed.
	-- we can use this to remove events or cancel timers that were associated with the object
	-- in this case when the player is removed we will remove collision eventListener (not technically needed).
	-- we should then nil out the display object and instance (for good memory management)
	self.player.finalize = function()
		if not self then return end
		Runtime:removeEventListener("contactHealth", self.changeHealth)
		self.player:removeEventListener("collision")
	
		Runtime:removeEventListener("rotationalVelocity", self.setRotationalVelocity)
		Runtime:removeEventListener("enterFrame", self.sendPlayerCoordinates)
		Runtime:removeEventListener("rRotation", self.setRRotation)
		Runtime:removeEventListener("lRotation", self.setLRotation)
		--Runtime:removeEventListener("playerLocation", self.sendPlayerCoordinates)
		if self.timer then
			timer.cancel(self.timer)
		end
		self.player = nil
		self = nil
		print("deconstructed Player")
		
	local options = {
		name="gameOver"
		}
		Runtime:dispatchEvent(options) --ends the game and changes scenes
		print"dispatch Gameover"
	end
	
	
	self.player:addEventListener("finalize")
end


	
return Player

-- https://forums.coronalabs.com/topic/27533-rotating-a-rocket-in-2d-and-moving-into-the-direction-it-is-facing/


--https://developer.coronalabs.com/forum/2012/11/14/fire-bullet-rotating-object


































