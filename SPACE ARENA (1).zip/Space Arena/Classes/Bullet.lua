-- =============================================================
-- Written by Craig Briggs.  Feel free to modify and reuse in anyway.
--
-- Bullet.lua
-- Bullet class,  creates the bullet that the player fires
--======================================================================--
--== Bullet Class factory
--======================================================================--
local Bullet = class() -- define Bullet as a class (notice the capitals)
Bullet.__name = "Bullet" -- give the class a name
--local Player = require ("Classes.Player")
--======================================================================--
--== Require dependant classes
--======================================================================--
local pt = require("Classes.printTable") -- helper class to use when developint
-- pt.print_r(....) will print the contents of a table

--======================================================================--
--== Initialization / Constructor
--======================================================================--
function Bullet:__init(group, speed, xloc, yLoc,rotation )
	-- Constructor for class
		-- Parameters:
		--	group - the group where the game should be inserted into
		--	xLoc, yLoc - location where it will be drawn
		--  speed - speed at which it will move
	self.group = group
	self.xloc =  xloc
	self.yloc =  yLoc
	self.rotation = rotation
	self.speed = speed
	self.bulletSpeed = bulletSpeed or 600
	-- call the method to draw the Bullet
	self:drawBullet()
	--print (self.bulletSpeed) -- debugger
	
	
end

--======================================================================--
--== Code / Methods
--======================================================================--

function Bullet:drawBullet()
	-- Displays the Bullet on the screen
	-- Recieves: nil
	-- Returns: nil
	
	-- draw the bullet
	self.bullet = display.newRect(self.group,self.xloc, self.yloc,  5,15)--display.newImageRect(self.group, "images/player.png", 30, 30 )
    self.bullet.id = "bullet"
	self.bullet.rotation = self.rotation
	-- move it up the screen, set it as a sensor so it doesnt cause
	-- issues with the player
	physics.addBody( self.bullet, "dynamic", {isSensor = true} )
	-- complex math so bullet fires accoring to player rotation which is pretty neat
	local xSpeed = self.bulletSpeed * math.sin(math.rad(self.bullet.rotation))
	local ySpeed = -self.bulletSpeed * math.cos(math.rad(self.bullet.rotation))
	self.bullet:setLinearVelocity(xSpeed,ySpeed)

	-- add collisions and deconstructor
	self:addCollision()
	self:deconstructor()
end

function Bullet:addCollision()
	-- if it collides with anything except the player then remove the bomb
	self.bullet.collision = function(target, event)
		if event.other.id == "enemy" then
		self:deconstructor()
		end
	end
	
	self.bullet:addEventListener("collision")
end



function Bullet:deconstructor()
	-- a finalize event is called when a display object is removed.
	-- we can use this to remove events or cancel timers that were associated with the object
	-- in this case when the bullet is removed we will remove collision event listeners (not technically needed).
	-- we should then nil out the display object and instance (for good memory management)
	self.bullet.finalize = function()
		if not self then return end
		self.bullet:removeEventListener("collision")
		display.remove(self.bullet)
		self.bullet = nil
		self = nil
	end
	self.bullet:addEventListener("finalize")
end
--======================================================================--
--== Return factory
--======================================================================--
return Bullet