-- =============================================================
-- Written by Yash Singh.  Feel free to modify and reuse in anyway.
--
-- game.lua
-- Main game class,  creates the environment and communicate between classes
-- =============================================================

--======================================================================--
--== Game Class factory
--======================================================================--
local Game = class() -- define Game as a class (notice the capitals)
Game.__name = "Game" -- give the class a name

--======================================================================--
--== Require dependant classes
--======================================================================--
local pt = require("Classes.printTable") -- helper class to use when developint
-- pt.print_r(....) will print the contents of a table
local Controls	 	= require ("Classes.Controls") -- 
local Boundary		= require ("Classes.Boundary")
local EnemyClass	= require ("Classes.Enemy")
local PlayerClass 	= require ("Classes.Player")
local bulletClass = require ("Classes.Bullet")


-- Constants
local fullw = display.contentWidth
local fullh = display.contentHeight
local centerX = display.contentCenterX
local centerY = display.contentCenterY

--======================================================================--
--== Initialization / Constructor
--======================================================================--
function Game:__init(group, options)
	-- Constructor for class
	-- Parameters:
	--		group - the group where the game should be inserted into
	--		options - table containing variables uses to set up the enviroment
	-- Returns:
	--		Reference to instance of class
	
	self.group = group -- the group where the game should be inserted into
	
	-- set up environment, sets default values of nothing is passed over
	local enemyDetails = options.enemyDetails or {}

	self.speed = enemyDetails.startSpeed or 100 -- start speed for the enemies

	
	local playerDetails = options.playerDetails or {}
	self.playerSpeed =  150 -- speed player moves across the screen
	self.bulletSpeed = playerDetails.bulletSpeed or 120 -- speed bullets fire up the screen
	self.bulletInterval = playerDetails.bulletInterval -- interval between bullets
	self.health = playerDetails.health or 100 -- sets health

	--self.lastWall = "" -- reference to the last wall that was collided with, used for enemies
						-- to keep track of movement
	--self.wallCount = 0 -- number of enemy wall collisions
	self.playerlRotate = -10
	self.playerrRotate = 10
	
end

--======================================================================--
--== Code / Methods
--======================================================================--



function Game:setUp()
	-- sets up the game enviroment
	
	-- draw the 3 controls
	local leftKey = Controls:new(self.group, centerX-20,fullh, "images/up.png", -90, "a")
	local rightKey = Controls:new(self.group, centerX+20,fullh, "images/up.png", 90, "d")
	local shootKey = Controls:new(self.group, centerX,fullh, "images/space.png", 0, "space")
	local upKey = Controls:new(self.group, centerX, fullh - 20, "images/up.png", 0, "w") 
	local downKey = Controls:new(self.group, centerX, fullh + 20, "images/up.png", -180, "s")
	

	
	-- draw the player
	self.Player =  PlayerClass:new(self.group,centerX,fullh - 100, self.bulletSpeed, self.bulletInterval, 1000)
	local enemies ={}
	for i = 1, 50 do
		local randX =  math.random(-100,-30) or math.random(350-400) -- spawns outside the screen
		local randY =  math.random(0,300)
		enemies[i] = 	EnemyClass:new(self.group, randX,randY, 6)
	end
end  

function Game:startGame()
	-- dispatch instructions to enemies to start moving
	local options = { 
		name = "enemyInstructions",
		action = "move",
		speed = self.speed
	}
	Runtime:dispatchEvent(options)
	self:deconstructor() 
end

function Game:listen()
	-- listen to for custom messages
	function self.keyPressed (self, event) -- if a key is pressed
		if event.phase == "began" then -- if it is beginning then tell the player to move or fire
			if event.key == "a" then
				local a = {
					name = "lRotation",
					lRotation = self.playerlRotate
					}	
				Runtime:dispatchEvent(a)
				
			end	
			if event.key == "d" then
				local d = {
					name = "rRotation",
					rRotation = self.playerrRotate
					}	
				Runtime:dispatchEvent (d)
			
			end	
			if event.key == "w" then
				local w = {
					name = "rotationalVelocity",
					playerSpeed = self.playerSpeed
					}	
				Runtime:dispatchEvent (w)
		
			end	
			if event.key == "s" then
				local s = {
					name = "rotationalVelocity",
					playerSpeed = -self.playerSpeed
					}	
				Runtime:dispatchEvent(s)
		
			end	
			
	
			if event.key == "space" then
			self.Player:fireBullet()
			--print ("firing bullet") - debugger
			end
		
			end
		end
	
	Runtime:addEventListener("keyPressed", self)
  
	
end

--function Game:gameOver()
	--self.gameOver = function() -- displays score in gameOver Scene
		--	local options = {
			--	name = "endGameScore",
		--	}
		--self.dispatchTimer = timer.performWithDelay(1200, function()
		--Runtime:dispatchEvent(options)
		--print("dispatchscore event")
	--	end)
	--end
	--Runtime:addEventListener("gameOver", self.gameOver)
--end

function Game:deconstructor() 
	self.group.finalize = function()
		-- a finalize event is called when a display object is removed.
		-- we can use this to remove events or cancel timers that were associated with the object
		-- in this case when the main group is removed we will remove two Runtime event listeners
		-- this is VERY important, because having these running in the background will VERY LIKELY
		-- cause an error down the line
		--self.group:removeSelf()
		--self.group = nil
		Runtime:removeEventListener("enemyTalk", self)
		Runtime:removeEventListener("keyPressed", self)
	end
	self.group:addEventListener("finalize")
end
--======================================================================--
--== Return factory
--======================================================================--
return Game
